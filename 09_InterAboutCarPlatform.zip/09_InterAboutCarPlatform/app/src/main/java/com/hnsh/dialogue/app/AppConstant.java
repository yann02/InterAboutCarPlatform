package com.hnsh.dialogue.app;


/**
 * des:
 * Created by xsf
 * on 2016.09.10:44
 */
public interface AppConstant {
  String FORM_LANG="form_lang_key";
  String FORM_COUNTRY_NAME="form_country_name_key";
  String FORM_LISTENING="form_listening";
  String TO_LANG="to_lang_key";
  String TO_COUNTRY_NAME="to_country_name_key";
  String TO_LISTENING="to_listening";
}
