package com.hnsh.dialogue.bean.cbs;

/**
 * @项目名： Sanya
 * @包名： com.dosmono.common.entity
 * @文件名: CustomCommand
 * @创建者: zer
 * @创建时间: 2019/8/3 14:09
 * @描述： TODO
 */
public class CustomCommand extends BaseRequest{
    private String content;

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
}
