package com.hnsh.dialogue.bean.cbs;

/**
 * @项目名： Translator
 * @包名： com.dosmono.common.entity
 * @文件名: SettingStoreInfo
 * @创建者: Administrator
 * @创建时间: 2018/3/1 001 18:02
 * @描述： TODO
 */

public class SettingStoreInfo {

    private int storType;
    private int storeLocation;

    public int getStorType() {
        return storType;
    }

    public void setStorType(int storType) {
        this.storType = storType;
    }

    public int getStoreLocation() {
        return storeLocation;
    }

    public void setStoreLocation(int storeLocation) {
        this.storeLocation = storeLocation;
    }
}
