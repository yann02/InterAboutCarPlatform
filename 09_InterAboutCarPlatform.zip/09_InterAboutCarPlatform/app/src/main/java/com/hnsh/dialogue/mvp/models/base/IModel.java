package com.hnsh.dialogue.mvp.models.base;

/**
 * Created by jess on 15/12/2016 10:45
 * Contact with jess.yan.effort@gmail.com
 */

public interface IModel {
    void onDestroy();
}
