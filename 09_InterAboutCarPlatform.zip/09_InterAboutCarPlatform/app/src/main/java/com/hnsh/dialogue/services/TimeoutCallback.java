package com.hnsh.dialogue.services;

public interface TimeoutCallback {

    void onTimeout();
}
