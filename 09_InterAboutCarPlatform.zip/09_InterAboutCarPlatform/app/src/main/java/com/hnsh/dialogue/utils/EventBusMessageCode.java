package com.hnsh.dialogue.utils;

/**
 * Created by Administrator on 2018/3/21.
 */

public class EventBusMessageCode {

    public static final String CONNECT_ETHERNET = "connect_ethernet";//连接以太网
    public static final String CONNET_WIFI = "connet_wifi";//连接WIFI
}
