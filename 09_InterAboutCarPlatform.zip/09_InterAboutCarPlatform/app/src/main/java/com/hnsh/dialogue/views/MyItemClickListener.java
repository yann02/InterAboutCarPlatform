package com.hnsh.dialogue.views;

import android.view.View;


/**
 * Created by acer- on 2017/7/30.
 */

public class MyItemClickListener {
    public void onItemClick(View view, int position){

    }

    public void onItemLongClick(View view, int position){

    }
}
